---
title: "About Data Minimal"
description: "Mission and principles."
---

Data Minimal simplifies learning data engineering. Clarity over clutter, depth over breadth, and production-minded examples.
