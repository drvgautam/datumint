---
title: "Data Modeling Minimalism"
description: "Star vs wide tables, semantic layers, and contracts—only what matters."
---

Model for **clarity and change**. Start wide → evolve to star as queries and teams grow. Use data contracts to pin schemas and SLIs.
