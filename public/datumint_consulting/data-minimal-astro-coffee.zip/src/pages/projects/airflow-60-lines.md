---
title: "Airflow in 60 Lines"
description: "A tiny but reliable daily DAG with retries and idempotent loads."
---

Minimal DAG skeleton with extract → transform → load steps and basic retries.
