---
title: "The Minimal Data Engineering Curriculum"
description: "Six weeks, six projects, evaluation checklist."
---

Build six small, reliable projects covering storage, orchestration, modeling, testing, and observability.
